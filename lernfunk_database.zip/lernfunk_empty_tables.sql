/*
Copyright (c) 2007 - 2010  Universitaet Osnabrueck, virtUOS
Authors: Nils Birnbaum, Lars Kiesow, Benjamin Wulff

This file is part of Lernfunk.

Lernfunk is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Lernfunk is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with virtPresenter.  If not, see <http://www.gnu.org/licenses/>.
*/


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `department`
-- 

CREATE TABLE `department` (
  `dep_id` int(11) NOT NULL auto_increment,
  `dep_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `dep_description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `dep_number` varchar(255) collate utf8_unicode_ci NOT NULL,
  `academy_id` int(11) NOT NULL default '0',
  PRIMARY KEY  (`dep_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=15 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `feeds`
-- 

CREATE TABLE `feeds` (
  `feed_id` int(11) NOT NULL auto_increment,
  `feed_url` varchar(245) collate utf8_unicode_ci NOT NULL,
  `series_id` int(11) NOT NULL,
  `feedtype_id` int(11) NOT NULL,
  `itunes_status` tinyint(3) unsigned NOT NULL default '1',
  PRIMARY KEY  (`feed_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=24 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `lecturer`
-- 

CREATE TABLE `lecturer` (
  `lecturer_id` int(11) NOT NULL auto_increment,
  `ac_title` varchar(255) collate utf8_unicode_ci NOT NULL,
  `firstname` varchar(255) collate utf8_unicode_ci NOT NULL,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `dep_id` int(11) NOT NULL default '1',
  `academy_id` int(11) NOT NULL default '1',
  `lms_lecturer_id` varchar(245) collate utf8_unicode_ci NOT NULL,
  `lec_url` text collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`lecturer_id`),
  FULLTEXT KEY `firstname` (`firstname`),
  FULLTEXT KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=104 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=104 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `lecturer_series`
-- 

CREATE TABLE `lecturer_series` (
  `lecturer_id` int(11) NOT NULL default '0',
  `series_id` int(11) NOT NULL default '0',
  `role` int(11) NOT NULL default '0',
  PRIMARY KEY  (`lecturer_id`,`series_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `lms`
-- 

CREATE TABLE `lms` (
  `lms_id` int(11) NOT NULL auto_increment,
  `name` varchar(245) collate utf8_unicode_ci default NULL,
  `contact_person` varchar(245) collate utf8_unicode_ci default NULL,
  `email` varchar(245) collate utf8_unicode_ci default NULL,
  `lms_identifier` varchar(245) collate utf8_unicode_ci NOT NULL,
  `lms_url` varchar(245) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`lms_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `lms_connect`
-- 

CREATE TABLE `lms_connect` (
  `connector_id` int(11) NOT NULL auto_increment,
  `series_id` int(11) NOT NULL,
  `lms_id` int(11) NOT NULL,
  `lms_course_id` varchar(245) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`connector_id`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=100 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `mediaobject`
-- 

CREATE TABLE `mediaobject` (
  `object_id` int(11) NOT NULL auto_increment,
  `title` varchar(245) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `series_id` int(11) NOT NULL,
  `date` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `lrs_object_id` varchar(245) collate utf8_unicode_ci default NULL,
  `format_id` int(11) NOT NULL,
  `url` varchar(245) collate utf8_unicode_ci NOT NULL,
  `memory_size` varchar(245) collate utf8_unicode_ci default NULL,
  `language_id` int(11) NOT NULL,
  `cou_id` varchar(245) collate utf8_unicode_ci NOT NULL,
  `author` varchar(245) collate utf8_unicode_ci default NULL,
  `thumbnail_url` varchar(245) collate utf8_unicode_ci default NULL,
  `preview_url` text collate utf8_unicode_ci,
  `image_url` text collate utf8_unicode_ci,
  `duration` varchar(245) collate utf8_unicode_ci default NULL,
  `location` varchar(245) collate utf8_unicode_ci default NULL,
  `add_url` varchar(245) collate utf8_unicode_ci default NULL,
  `add_url_text` varchar(245) collate utf8_unicode_ci default NULL,
  `access_id` int(11) NOT NULL,
  `itunesu_class` int(6) NOT NULL,
  PRIMARY KEY  (`object_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3937 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3937 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `mediascene`
-- 

CREATE TABLE `mediascene` (
  `scene_id` int(11) NOT NULL auto_increment,
  `object_id` int(11) NOT NULL,
  `title` varchar(245) collate utf8_unicode_ci NOT NULL,
  `description` varchar(245) collate utf8_unicode_ci NOT NULL,
  `msu_id` varchar(245) collate utf8_unicode_ci NOT NULL,
  `scene_url` varchar(256) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`scene_id`)
) ENGINE=MyISAM AUTO_INCREMENT=382 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=382 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `playlist`
-- 

CREATE TABLE `playlist` (
  `playlist_id` int(11) NOT NULL auto_increment,
  `reciever_id` int(11) NOT NULL,
  `pl_title` varchar(245) collate utf8_unicode_ci NOT NULL,
  `pl_description` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`playlist_id`)
) ENGINE=MyISAM AUTO_INCREMENT=120 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=120 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `playlist_entry`
-- 

CREATE TABLE `playlist_entry` (
  `playlist_id` int(11) NOT NULL,
  `object_id` int(11) NOT NULL,
  `index_position` int(11) default NULL,
  `access_id` int(11) default NULL,
  `start_access` timestamp NULL default NULL,
  `stop_access` timestamp NULL default NULL,
  PRIMARY KEY  (`playlist_id`,`object_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `role`
-- 

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL auto_increment,
  `role` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `series`
-- 

CREATE TABLE `series` (
  `series_id` int(11) NOT NULL auto_increment,
  `name` varchar(245) collate utf8_unicode_ci NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `description_sh` varchar(245) collate utf8_unicode_ci default NULL,
  `term_id` int(11) NOT NULL,
  `course_id` int(11) NOT NULL,
  `access_id` int(11) NOT NULL,
  `portal_url` varchar(245) collate utf8_unicode_ci NOT NULL,
  `clas_id` int(11) NOT NULL,
  `thumbnail_url` varchar(245) collate utf8_unicode_ci NOT NULL default 'http://zentrum.virtuos.uos.de/wikifarm/fields/podcasts/uploads/Main/vorschau.jpg',
  `lms_course_id` varchar(245) collate utf8_unicode_ci NOT NULL,
  `add_url` varchar(245) collate utf8_unicode_ci NOT NULL,
  `add_url_text` varchar(245) collate utf8_unicode_ci NOT NULL,
  `lrs_series_id` varchar(245) collate utf8_unicode_ci NOT NULL,
  `social_web` int(11) NOT NULL default '0',
  `keywords` varchar(245) collate utf8_unicode_ci NOT NULL,
  `cat_id` int(11) NOT NULL default '2',
  `default_playlist_id` int(11) default NULL,
  PRIMARY KEY  (`series_id`)
) ENGINE=MyISAM AUTO_INCREMENT=174 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=174 ;

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `tag`
-- 

CREATE TABLE `tag` (
  `tagname` varchar(64) collate utf8_bin NOT NULL,
  `count` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`tagname`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Generated Mon May 24 04:00:04 2010 by lftagdaemon';
