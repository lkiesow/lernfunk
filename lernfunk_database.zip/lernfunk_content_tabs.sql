/*
Copyright (c) 2007 - 2010  Universitaet Osnabrueck, virtUOS
Authors: Nils Birnbaum, Lars Kiesow, Benjamin Wulff

This file is part of Lernfunk.

Lernfunk is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

Lernfunk is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with virtPresenter.  If not, see <http://www.gnu.org/licenses/>.
*/

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `academy`
-- 

CREATE TABLE `academy` (
  `academy_id` int(11) NOT NULL auto_increment,
  `ac_name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ac_contact` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ac_contact_person` varchar(255) collate utf8_unicode_ci NOT NULL,
  `ac_email` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`academy_id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `access`
-- 

CREATE TABLE `access` (
  `access_id` int(11) NOT NULL auto_increment,
  `status` varchar(245) collate utf8_unicode_ci NOT NULL,
  `vp_access` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`access_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

-- 
-- Daten für Tabelle `access`
-- 

INSERT INTO `access` (`access_id`, `status`, `vp_access`) VALUES (1, 'Öffentlich', 'public'),
(2, 'Zugriff über Stud.IP', 'lms course'),
(3, 'Wartet auf Freigabe', 'pending'),
(6, 'Login und Passwort erforderlic', NULL),
(8, 'unsichtbar', 'hidden'),
(9, 'Trash', NULL);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `audience`
-- 

CREATE TABLE `audience` (
  `audience_id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` varchar(500) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`audience_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Daten für Tabelle `audience`
-- 

INSERT INTO `audience` (`audience_id`, `name`, `description`) VALUES (1, 'Studenten', 'die Leute die immer schlafen');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `category`
-- 

CREATE TABLE `category` (
  `cat_id` int(11) NOT NULL auto_increment,
  `category` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=7 ;

-- 
-- Daten für Tabelle `category`
-- 

INSERT INTO `category` (`cat_id`, `category`) VALUES (4, 'Vorlesung'),
(5, 'Übung'),
(1, 'Unbekannt'),
(2, 'Vorlesung'),
(3, 'Übung'),
(6, 'Lernmodul');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `elan_classification`
-- 

CREATE TABLE `elan_classification` (
  `clas_id` int(11) NOT NULL auto_increment,
  `classification` varchar(255) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`clas_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- 
-- Daten für Tabelle `elan_classification`
-- 


-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `feedtype`
-- 

CREATE TABLE `feedtype` (
  `feedtype_id` int(11) NOT NULL auto_increment,
  `feedtype_desc` varchar(245) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`feedtype_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Daten für Tabelle `feedtype`
-- 

INSERT INTO `feedtype` (`feedtype_id`, `feedtype_desc`) VALUES (1, 'Audio Podcast'),
(2, 'Video Podcast'),
(3, 'Screenvideo Podcast');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `itunesu_classification`
-- 

CREATE TABLE `itunesu_classification` (
  `code` int(11) NOT NULL,
  `name` varchar(265) collate utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- 
-- Daten für Tabelle `itunesu_classification`
-- 

INSERT INTO `itunesu_classification` (`code`, `name`) VALUES (100, 0x427573696e657373),
(100100, 0x45636f6e6f6d696373),
(100101, 0x46696e616e6365),
(100102, 0x486f73706974616c697479),
(100103, 0x4d616e6167656d656e74),
(100104, 0x4d61726b6574696e67),
(100105, 0x506572736f6e616c2046696e616e6365),
(100106, 0x5265616c20457374617465),
(101, 0x456e67696e656572696e67),
(101100, 0x4368656d6963616c202620506574726f6c65756d),
(101101, 0x436976696c),
(101102, 0x436f6d707574657220536369656e6365),
(101103, 0x456c656374726963616c),
(101104, 0x456e7669726f6e6d656e74616c),
(101105, 0x4d656368616e69636c),
(102, 0x46696e652041727473),
(102100, 0x417263686974656374757265),
(102101, 0x417274),
(102102, 0x41727420486973746f7279),
(102103, 0x44616e6365),
(102104, 0x46696c6d),
(102105, 0x4772617069632044657369676e),
(102106, 0x496e746572696f722044657369676e),
(102107, 0x4d75736963),
(102108, 0x54686561746572),
(103, 0x4865616c74682026204d65646963696e65),
(103100, 0x416e61746f6d7920262050687973696f6c6f6779),
(103101, 0x4265686176696f757220536369656e6365),
(103102, 0x44656e746973747279),
(103103, 0x446965742026204e7574726974696f6e),
(103104, 0x456d657267656e6379),
(103105, 0x47656e6574696373),
(103106, 0x4765726f6e746f6c6f6779),
(103107, 0x4865616c7468202620457865726369736520536369656e6365),
(103108, 0x496d6d756e6f6c6f6779),
(103109, 0x4e6575726f736369656e6365),
(103110, 0x506861726d61636f6c6f6779202620546f7869636f6c6f6779),
(103111, 0x507379636861747279),
(103112, 0x5075626c6963204865616c7468),
(103113, 0x526164696f6c6f6779),
(104, 0x486973746f7279),
(104100, 0x416e6369656e74),
(104101, 0x4d6564696576616c),
(104102, 0x4d696c6974617279),
(104103, 0x4d6f6465726e),
(104104, 0x416672696361),
(104105, 0x417369616e),
(104106, 0x4575726f7065616e),
(104107, 0x4d6964646c65204561737465726e),
(104108, 0x4e6f72746820416d65726963616e),
(104109, 0x536f75746820416d65726963616e),
(105, 0x48756d616e6974696573),
(105100, 0x436f6d6d756e69636174696f6e73),
(105101, 0x5068696c6f736f706879),
(105102, 0x52656c6967696f6e),
(106, 0x4c616e6775616765),
(106100, 0x4166726963616e),
(106101, 0x416e6369656e74),
(106102, 0x417369616e),
(106103, 0x4561737465726e204575726f7065616e2f536c61766963),
(106104, 0x456e676c697368),
(106105, 0x456e676c697368204c616e6775616765204c6561726e657273),
(106106, 0x4672656e6368),
(106107, 0x4765726d616e),
(106108, 0x4974616c69656e),
(106109, 0x4c696e6775697374696373),
(106110, 0x4d6964646c65204561737465726e),
(106111, 0x5370616e697368202620506f7274756775657365),
(106112, 0x53706565636820506174686f6c6f6779),
(107, 0x4c697465726174757265),
(107100, 0x416e74686f6c6f67696573),
(107101, 0x42696f677261706879),
(107102, 0x436c617373696373),
(107103, 0x43726974696369736d),
(107104, 0x46696374696f6e),
(107105, 0x506f65747279),
(108, 0x4d617468656d6174696373),
(108100, 0x416476616e636564204d617468656d6174696373),
(108101, 0x416c6765627261),
(108102, 0x41726974686d65746963),
(108103, 0x43616c63756c7573),
(108104, 0x47656f6d65747279),
(108105, 0x53746174697374696373),
(109, 0x536369656e6365),
(109100, 0x4167726963756c747572616c),
(109101, 0x417374726f6e6f6d79),
(109102, 0x41746d6f73706865726963),
(109103, 0x42696f6c6f6779),
(109104, 0x4368656d6973747279),
(109105, 0x45636f6c6f6779),
(109106, 0x47656f677261706879),
(109107, 0x47656f6c6f6779),
(109108, 0x50687973696373),
(110, 0x536f6369616c205369656e6365),
(110100, 0x4c6177),
(110101, 0x506f6c69746963616c20536369656e6365),
(110102, 0x5075626c69632041646d696e697374726174696f6e),
(101103, 0x50737963686f6c6f6779),
(110104, 0x536f6369616c2057656c66617265),
(110105, 0x536f63696f6c6f6779),
(111, 0x536f63696f6c6f6779),
(111100, 0x4166726963616e2d416d65726963616e2053747564696573),
(111101, 0x417369616e2053747564696573),
(111102, 0x4575726f7065616e2026205275737369616e2053747564696573),
(111103, 0x496e6967656e6f75732053747564696573),
(111104, 0x4c6174696e20262043617269626265616e2053747564696573),
(111105, 0x4d6964646c65204561737465726e2053747564696573),
(111106, 0x576f6d656e27732053747564696573),
(112, 0x5465616368696e67202620456475636174696f6e),
(112100, 0x437572726963756c756d2026205465616368696e67),
(112101, 0x456475636174696f6e616c204c656164657273686970),
(112102, 0x46616d696c792026204368696c6463617265),
(112103, 0x4c6561726e696e67205265736f7572636573),
(112104, 0x50737963686f6c6f67792026205265736561726368),
(112105, 0x5370656369616c20456475636174696f6e);

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `language`
-- 

CREATE TABLE `language` (
  `lang_id` int(11) NOT NULL auto_increment,
  `language_long` varchar(245) collate utf8_unicode_ci NOT NULL,
  `language_short` varchar(245) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`lang_id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=4 ;

-- 
-- Daten für Tabelle `language`
-- 

INSERT INTO `language` (`lang_id`, `language_long`, `language_short`) VALUES (1, 'Deutsch', 'de'),
(2, 'Englisch', 'eng'),
(3, 'Finnisch', 'fin');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `role`
-- 

CREATE TABLE `role` (
  `role_id` int(11) NOT NULL auto_increment,
  `role` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`role_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

-- 
-- Daten für Tabelle `role`
-- 

INSERT INTO `role` (`role_id`, `role`) VALUES (1, 'Lecturer');

-- --------------------------------------------------------

-- 
-- Tabellenstruktur für Tabelle `terms`
-- 

CREATE TABLE `terms` (
  `term_id` int(11) NOT NULL auto_increment,
  `term_sh` varchar(255) collate utf8_unicode_ci NOT NULL,
  `term_lg` varchar(255) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`term_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=20 ;

-- 
-- Daten für Tabelle `terms`
-- 

INSERT INTO `terms` (`term_id`, `term_sh`, `term_lg`) VALUES (1, 'WS 01/02', 'Wintersemester 01/02'),
(2, 'SS 02', 'Sommersemester 2002'),
(3, 'WS 02/03', 'Wintersemester 02/03'),
(4, 'SS 03', 'Sommersemester 2003'),
(5, 'WS 03/04', 'Wintersemester 03/04'),
(6, 'SS 04', 'Sommersemester 2004'),
(7, 'WS 04/05', 'Wintersemester 04/05'),
(8, 'SS 05', 'Sommersemester 2005'),
(9, 'WS 05/06', 'Wintersemester 05/06'),
(10, 'SS 06', 'Sommersemester 2006'),
(11, 'WS 06/07', 'Wintersemester 06/07'),
(12, 'SS 07', 'Sommersemester 2007'),
(13, 'Konferenz/Tagung', ''),
(14, 'WS 07/08', 'Wintersemester 07/08'),
(15, 'SS 08', 'Sommersemester 2008'),
(16, 'WS 08/09', 'Wintersemester 08/09'),
(17, 'SS 09', 'Sommersemester 2009'),
(18, 'WS 09/10', 'Wintersemester 09/10'),
(19, 'SS 10', 'Sommersemester 2010');
